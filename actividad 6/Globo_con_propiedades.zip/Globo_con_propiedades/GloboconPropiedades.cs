﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Globo_con_propiedades
{
    class GloboconPropiedades
    {
        //variables o propiedades
        public int x = 1;
        public int y = 2;
        //Definición de método
        public void Mostrar(/*parámetros*/Graphics areaDibujo) //Definición
        {
            //Cuerpo del método
            Pen pen = new Pen(Color.Black);
            areaDibujo.DrawEllipse(pen, 100, 100, 100, 100);
        }
    }
}
