﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Globo_con_propiedades
{
    public partial class Form1 : Form
    {
        //Declaración de variables u objetos
        GloboconPropiedades globoconPropiedades;
        Graphics areaDibujo;
        int x;
        GloboconPropiedades globocon = new GloboconPropiedades();
       //Este es el constructor de la clase
        public Form1()
        {
            InitializeComponent();
            areaDibujo = pictureBox1.CreateGraphics();
        }
        //Fin del constructor
        private void Form1_Load(object sender, EventArgs e)
        {
            label2.Text = "(" + pictureBox1.Width + ",0)";
            label3.Text = "(0," + pictureBox1.Height + ")";
            label4.Text = "(" + pictureBox1.Width + "," + pictureBox1.Height + ")";
            globocon.x = 50;
            label5.Text = "x = " + globocon.x;
            label6.Text = "y = " + globocon.y;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            globocon.Mostrar(areaDibujo);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
